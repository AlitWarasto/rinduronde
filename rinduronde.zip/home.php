<?php 



include(TEMPLATEPATH.'/header.php');



include(TEMPLATEPATH.'/footer.php');
 ?>