		<section class="footer3 cid-s48P1Icc8J" once="footers" id="footer3-i">
      <div class="container">
        <div class="media-container-row align-center mbr-white">
          <div class="row row-links">
            <ul class="foot-menu">
              <li class="foot-menu-item mbr-fonts-style display-7"><a style="color: aliceblue;" href="https://wa.me/6289607916051">Hubungi Kami</a></li>
              <li class="foot-menu-item mbr-fonts-style display-7"><a style="color: aliceblue;" href="#">Lokasi</a></li>
              <li class="foot-menu-item mbr-fonts-style display-7"><a style="color: aliceblue;" href="#">rinduronde.com</a></li>
            </ul>
          </div>
          <div class="row social-row">
            <div class="social-list align-right pb-2">
              <div class="soc-item">
                <a href="#" target="_blank"> <span class="socicon-twitter socicon mbr-iconfont mbr-iconfont-social"></span> </a>
              </div>
              <div class="soc-item">
                <a href="#" target="_blank"> <span class="socicon-facebook socicon mbr-iconfont mbr-iconfont-social"></span> </a>
              </div>
              <div class="soc-item">
                <a href="#" target="_blank"> <span class="socicon-youtube socicon mbr-iconfont mbr-iconfont-social"></span> </a>
              </div>
              <div class="soc-item">
                <a href="#" target="_blank"> <span class="mbr-iconfont mbr-iconfont-social socicon-instagram socicon"></span> </a>
              </div>
            </div>
          </div>
          <div class="row row-copirayt"><p class="mbr-text mb-0 mbr-fonts-style mbr-white align-center display-7">© Copyright 2021 rinduronde. All Rights Reserved.</p></div>
        </div>
      </div>
    </section>
    <section style="background-color: #fff; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Helvetica Neue', Arial, sans-serif; color: #aaa; font-size: 12px; padding: 0; align-items: center; display: none;">
      <a href="https://mobirise.site/g" style="flex: 1 1; height: 3rem; padding-left: 1rem;"></a>
      <p style="flex: 0 0 auto; margin: 0; padding-right: 1rem;"><a href="https://mobirise.site" style="color: #aaa;">Mobirise</a> html site maker</p>
    </section>
    <a id="btnFly" class="btn btn-secondary display-4" href="https://wa.me/6289607916051"><span class="mobi-mbri mobi-mbri-users mbr-iconfont mbr-iconfont-btn"></span>Join Us</a>
    <script src="assets/web/assets/jquery/jquery.min.js"></script>
    <script src="assets/popper/popper.min.js"></script>
    <script src="assets/tether/tether.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/smoothscroll/smooth-scroll.js"></script>
    <script src="assets/parallax/jarallax.min.js"></script>
    <script src="assets/dropdown/js/nav-dropdown.js"></script>
    <script src="assets/dropdown/js/navbar-dropdown.js"></script>
    <script src="assets/touchswipe/jquery.touch-swipe.min.js"></script>
    <script src="assets/theme/js/script.js"></script>
   	
  	<?php wp_footer(); ?>
	</body>
</html>